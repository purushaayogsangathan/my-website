<?php
// Basic server configuration. Change ADMIN_EMAIL if needed.
const ADMIN_EMAIL = 'purush.ayog.sangathan@gmail.com';
const SITE_NAME = 'पुरुष आयोग संगठन फाउंडेशन';
const ADMIN_USERNAME = 'admin';
const DB_FILE = __DIR__ . '/data/complaints.sqlite';

// Default password: Purush@2026#Admin
const DEFAULT_ADMIN_HASH = '$2y$12$JIV.rHChNadaXQyyPoxTL.Yqv9bis5/ADL6wralDsZGACGJgLZAfe';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!extension_loaded('pdo_sqlite')) {
        http_response_code(500);
        exit('Server setup error: PDO SQLite extension is not enabled.');
    }
    $dir = dirname(DB_FILE);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec("CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_no TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        location TEXT,
        complaint TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY CHECK (id=1),
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    )");
    $stmt = $pdo->query('SELECT COUNT(*) FROM admins');
    if ((int)$stmt->fetchColumn() === 0) {
        $s = $pdo->prepare('INSERT INTO admins(id,username,password_hash) VALUES(1,?,?)');
        $s->execute([ADMIN_USERNAME, DEFAULT_ADMIN_HASH]);
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT NOT NULL
    )");
    return $pdo;
}
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function require_admin(){
    session_start();
    if (empty($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }
}
function csrf_token(){
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(){
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(403); exit('Invalid request.'); }
}
