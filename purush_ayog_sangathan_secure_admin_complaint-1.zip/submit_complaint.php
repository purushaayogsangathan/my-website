<?php
require __DIR__.'/config.php';
$name=trim($_POST['name']??''); $phone=preg_replace('/\D+/','',$_POST['phone']??'');
$email=trim($_POST['email']??''); $location=trim($_POST['location']??''); $complaint=trim($_POST['complaint']??'');
if(!$name || !preg_match('/^[0-9]{10}$/',$phone) || !$complaint || empty($_POST['consent'])) exit('कृपया सभी जरूरी जानकारी सही भरें।');
if($email && !filter_var($email,FILTER_VALIDATE_EMAIL)) exit('ई-मेल सही नहीं है।');
$pdo=db();
$no='PAF-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
$now=date('Y-m-d H:i:s');
$stmt=$pdo->prepare('INSERT INTO complaints(complaint_no,name,phone,email,location,complaint,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)');
$stmt->execute([$no,$name,$phone,$email,$location,$complaint,'Pending',$now,$now]);
$subject=SITE_NAME.' - नई शिकायत '.$no;
$body="नई शिकायत प्राप्त हुई है।\n\nशिकायत संख्या: $no\nनाम: $name\nमोबाइल: $phone\nई-मेल: $email\nजिला/शहर: $location\n\nविवरण:\n$complaint\n\nAdmin Panel में login करके स्थिति देखें।";
@mail(ADMIN_EMAIL,$subject,$body,"From: noreply@".($_SERVER['HTTP_HOST']??'localhost')."\r\nContent-Type: text/plain; charset=UTF-8\r\n");
if($email){ @mail($email,SITE_NAME.' - शिकायत प्राप्ति '.$no,"आपकी शिकायत प्राप्त हुई है।\n\nशिकायत संख्या: $no\nस्थिति: Pending\n\nकृपया इस शिकायत संख्या को सुरक्षित रखें।", "From: noreply@".($_SERVER['HTTP_HOST']??'localhost')."\r\nContent-Type: text/plain; charset=UTF-8\r\n"); }
?>
<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>शिकायत प्राप्ति</title><style>body{font-family:Arial,sans-serif;background:#f7f4ed;padding:25px}.receipt{max-width:700px;margin:30px auto;background:#fff;padding:30px;border-radius:16px;box-shadow:0 5px 25px #0002}.gold{color:#5a3c10}button,a{display:inline-block;padding:11px 18px;border-radius:8px;text-decoration:none;margin:8px 5px 0 0}.print{background:#d9a52e;color:#111}.home{background:#222;color:#fff}</style></head><body><div class="receipt"><h1 class="gold">शिकायत प्राप्ति रसीद</h1><p>आपकी शिकायत सफलतापूर्वक दर्ज कर ली गई है।</p><h2 class="gold">शिकायत संख्या: <?=e($no)?></h2><p><b>नाम:</b> <?=e($name)?></p><p><b>स्थिति:</b> Pending</p><p><b>दिनांक:</b> <?=e($now)?></p><p>इस शिकायत संख्या को सुरक्षित रखें।</p><button class="print" onclick="window.print()">🖨️ रसीद प्रिंट / PDF</button><a class="home" href="index.php">मुख्य पेज</a></div></body></html>
