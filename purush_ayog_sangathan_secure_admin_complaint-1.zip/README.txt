SECURE COMPLAINT + ADMIN WEBSITE

1) Upload all files to PHP hosting (PHP 8+ recommended).
2) The /data folder must be writable by PHP (normally 755/775 depending on host).
3) Open index.php for the public website.
4) Open admin.php for Admin login.
5) Default Admin username: admin
6) Default Admin password: Purush@2026#Admin
7) After first login, change the password from the Admin Panel.
8) Complaint data is stored server-side in data/complaints.sqlite.
9) New complaint notification and complainant receipt email use PHP mail(). On many hosts, mail() requires a verified domain/mail setup; if mail does not arrive, configure the hosting SMTP/mail service.
10) This package does not include real-time push notifications. The Admin Panel shows all new complaints; email alerts depend on the hosting mail configuration.

Security note: Use HTTPS and do not share the Admin password. The complaint form should not be used to submit passwords, OTPs, bank details, or other unnecessary sensitive information.
